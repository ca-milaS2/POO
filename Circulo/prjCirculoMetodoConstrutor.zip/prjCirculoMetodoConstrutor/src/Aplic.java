
import java.util.Scanner;

/**
 *
 * @author Yuki
 */

public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        double medRaio;
        String unidade;
        
        System.out.println("Digite o raio do círculo: ");
        medRaio = entrada.nextDouble();
        System.out.println("Digite a unidade de medida do círculo: ");
        unidade = entrada.next();
        
        Circulo objCirc = new Circulo(unidade);
        
        objCirc.setRaio(medRaio);
        
        System.out.println("\n------------------------------------");
        System.out.println("A medida do raio do círculo:      " + objCirc.getRaio() + objCirc.getUnidadeMedida());
        System.out.println("\nA medida da área do círculo:      " + objCirc.calcArea() + objCirc.getUnidadeMedida() + "²");
        System.out.println("A medida do perímetro do círculo: " + objCirc.calcPerimetro() + objCirc.getUnidadeMedida());
        System.out.println("A medida do diâmetro do círculo:  " + objCirc.calcDiametro() + objCirc.getUnidadeMedida());
        System.out.println("------------------------------------");
    }
}