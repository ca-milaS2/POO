
package fatec.poo.model;

import javax.swing.JOptionPane;

/**
 *
 * @author Camila Cezar
 */
public class GameShop {
    private int codigo, idade, saldo;
    private String nome;
    private boolean tipoGamer;
    
    public GameShop(int codigo, String nome, boolean tipoGamer, int saldo) {
        this.codigo = codigo;
        this.nome = nome;
        this.tipoGamer = tipoGamer; //  false-Esporádico      true-Frequente
        this.saldo = saldo;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public int getCodigo() {
        return codigo;
    }

    public int getSaldo() {
        return saldo;
    }

    public String getNome() {
        return nome;
    }

    public boolean isTipoGamer() {
        return tipoGamer;
    }
    
    public void jogarHoras(int qtdeJogadas) {
        if(qtdeJogadas > saldo) {
            JOptionPane.showMessageDialog(null, "Saldo de horas insuficiente!", "Erro", JOptionPane.WARNING_MESSAGE);
        }
        else {
            saldo = saldo - qtdeJogadas;
        }
    }
    
    public void comprarHoras(int qtdeComprada) {
        if(tipoGamer == true) {
            saldo = saldo + qtdeComprada + ((int) qtdeComprada/3);
        }
        else {
            saldo = saldo + qtdeComprada;
        }
    }
    
    public void brind() {
        saldo = saldo * 2;
    }
}
