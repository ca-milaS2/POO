
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class Departamento {
    private String sigla, nome;

    public Departamento(String sigla, String nome) {
        this.sigla = sigla;
        this.nome = nome;
    }    

    public String getSigla() {
        return sigla;
    }

    public String getNome() {
        return nome;
    }
}
