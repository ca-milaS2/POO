
import fatec.poo.model.Departamento;
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista objFuncHorTrab = new FuncionarioHorista(1010, "Pedro Silverira", 
                                                                         "14/05/1978", 15.80);
        
        FuncionarioMensalista objFuncMensTrab = new FuncionarioMensalista(1212, "Carla Silveira", 
                                                                                "03/09/1986", 850);
        
        FuncionarioComissionado objFunComisTrab = new FuncionarioComissionado(1313, "Robson Silveira", 
                                                                                    "11/05/2000", 10);
        
        Departamento dep1 = new Departamento("CP", "Compras");
        
        objFuncHorTrab.setCargo("Garçom");
        objFuncMensTrab.setCargo("Cozinheira");
        objFunComisTrab.setCargo("Ajudante");
       
        // estabelecendo o apontamento entre um objeto da classe 
        // FuncionarioHorista com um objeto da classe Departamento
        objFuncHorTrab.setDepartamento(dep1);
        System.out.println("O(a) funcionário(a) horista: " + objFuncHorTrab.getNome() + 
                           " trabalha no departamento de " + objFuncHorTrab.getDepartamento().getNome());
        
        objFuncMensTrab.setDepartamento(dep1);
        System.out.println("O(a) funcionário(a) mensalista: " + objFuncMensTrab.getNome() + 
                           " trabalha no departamento de " + objFuncMensTrab.getDepartamento().getNome());
    }
    
}
