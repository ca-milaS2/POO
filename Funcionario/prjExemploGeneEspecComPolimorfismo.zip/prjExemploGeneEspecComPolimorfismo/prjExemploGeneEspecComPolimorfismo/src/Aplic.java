
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista objFuncHorTrab = new FuncionarioHorista(1010, "Pedro Silverira", 
                                                                         "14/05/1978", "Garçom", 15.80);
        objFuncHorTrab.setQtdeHorTrab(90);
        System.out.println("\t\tFUNCIONÁRIO(A) HORISTA");
        System.out.println("Nome: " + objFuncHorTrab.getNome());
        System.out.println("Registro: " + objFuncHorTrab.getRegistro());
        System.out.println("Data de Admissão: " + objFuncHorTrab.getDtAdmissao());
        System.out.println("Cargo: " + objFuncHorTrab.getCargo());
        System.out.println("- Salário Bruto:   => " + objFuncHorTrab.calcSalBruto());
        System.out.println("- Desconto         => " + objFuncHorTrab.calcDesconto());
        System.out.println("- Salário Líquido: => " + objFuncHorTrab.calcSalLiquido());
        System.out.println("- Gratificação:    => " + objFuncHorTrab.calcGratificacao());
        
        FuncionarioMensalista objFuncMensTrab = new FuncionarioMensalista(1212, "Carla Silveira", 
                                                                                "03/09/1986", "Cozinheira" , 1518.00);
        objFuncMensTrab.setNumSalMin(2);
        System.out.println("\n\n\t\tFUNCIONÁRIO(A) MENSALISTA");
        System.out.println("Nome: " + objFuncMensTrab.getNome());
        System.out.println("Registro: " + objFuncMensTrab.getRegistro());
        System.out.println("Data de Admissão: " + objFuncMensTrab.getDtAdmissao());
        System.out.println("Cargo: " + objFuncMensTrab.getCargo());
        System.out.println("- Salário Bruto   => " + objFuncMensTrab.calcSalBruto());
        System.out.println("- Desconto        => " + objFuncMensTrab.calcDesconto());
        System.out.println("- Salário Líquido => " + objFuncMensTrab.calcSalLiquido());
    }
}
