
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class FuncionarioMensalista extends Funcionario {
    private double valSalMin, numSalMin;
    
    public FuncionarioMensalista(int r, String n, String dta, String c, double vsm) {
        super(r, n, dta, c);
        valSalMin = vsm;
    }
    
    public void setNumSalMin(double nsm) {
        numSalMin = nsm;
    }
    
    public double calcSalBruto() {
        return (valSalMin * numSalMin);
    }
    
    public double calcSalLiquido() {
        return (calcSalBruto() - calcDesconto());
    }
}