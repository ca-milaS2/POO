
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public abstract class Funcionario {
    private int registro;
    private String nome, dtAdmissao, cargo;
    
    public Funcionario(int r, String n, String dta, String c) {
        registro = r;
        nome = n;
        dtAdmissao = dta;
        cargo = c;
    }
    
    abstract public double calcSalBruto(); //método abstrato, apresenta apenas a assinatura
    
    public double calcDesconto() {
        return (0.10 * calcSalBruto());
    }
    
    abstract public double calcSalLiquido();
    
    public int getRegistro() {
        return registro;
    }
    
    public String getNome() {
        return nome;
    }
    
    public String getDtAdmissao() {
        return dtAdmissao;
    }
    
    public String getCargo() {
        return cargo;
    }
}