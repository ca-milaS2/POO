
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public abstract class Funcionario {
    private int registro;
    private String nome, dtAdmissao;
    
    public Funcionario(int r, String n, String dta) {
        registro = r;
        nome = n;
        dtAdmissao = dta;
    }
    
    abstract public double calcSalBruto(); //método abstrato, apresenta apenas a assinatura
    
    public double calcDesconto() {
        return (0.10 * calcSalBruto());
    }
    
    public double calSalLiquido() {
        return (calcSalBruto() - calcDesconto());
    }
}