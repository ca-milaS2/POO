
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class FuncionarioMensalista {
    
}
