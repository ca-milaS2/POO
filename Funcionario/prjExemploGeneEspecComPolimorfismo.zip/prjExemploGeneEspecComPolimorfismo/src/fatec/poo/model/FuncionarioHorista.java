
package fatec.poo.model;

/**
 *
 * @author Yuki
 */
public class FuncionarioHorista extends Funcionario{
    private double valHorTrab;
    private int qtdHorTrab;
    
    public FuncionarioHorista(int r, String n, String dta, double vht) {
        super(r, n, dta);
        valHorTrab = vht;
    }
    
    public void setQtdeHorTrab(int qtd) {
        qtdHorTrab = qtd;
    }
    
    public double calcSalBruto() {
        return (valHorTrab * qtdHorTrab);
    }
}