
import fatec.poo.model.FuncionarioHorista;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        FuncionarioHorista objFuncHorTrab = new FuncionarioHorista(1010, "Pedro Silverira", 
                                                                          "14/05/1978", 15.80);
        
        System.out.println("Salário Bruto:   " + objFuncHorTrab.calcSalBruto());
        System.out.println("Desconto         " + objFuncHorTrab.calcDesconto());
        System.out.println("Salário Líquido: " + objFuncHorTrab.calSalLiquido());
        
    }
    
}
