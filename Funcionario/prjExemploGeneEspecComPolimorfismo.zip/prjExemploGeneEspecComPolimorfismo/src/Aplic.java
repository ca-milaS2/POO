
import fatec.poo.model.FuncionarioComissionado;
import fatec.poo.model.FuncionarioHorista;
import fatec.poo.model.FuncionarioMensalista;
import java.util.Scanner;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        int opcao;
        double valVenda;
        
        FuncionarioHorista objFuncHorTrab = new FuncionarioHorista(1010, "Pedro Silverira", 
                                                                         "14/05/1978", 15.80);
        objFuncHorTrab.setQtdeHorTrab(90);
        objFuncHorTrab.setCargo("Garçom");
        System.out.println("\t\tFUNCIONÁRIO(A) HORISTA");
        System.out.println("Nome: " + objFuncHorTrab.getNome());
        System.out.println("Registro: " + objFuncHorTrab.getRegistro());
        System.out.println("Data de Admissão: " + objFuncHorTrab.getDtAdmissao());
        System.out.println("Cargo: " + objFuncHorTrab.getCargo());
        System.out.println("- Salário Bruto:   => " + objFuncHorTrab.calcSalBruto());
        System.out.println("- Desconto         => " + objFuncHorTrab.calcDesconto());
        System.out.println("- Salário Líquido: => " + objFuncHorTrab.calcSalLiquido());
        System.out.println("- Gratificação:    => " + objFuncHorTrab.calcGratificacao());
        
        FuncionarioMensalista objFuncMensTrab = new FuncionarioMensalista(1212, "Carla Silveira", 
                                                                                "03/09/1986", 850.00);
        objFuncMensTrab.setNumSalMin(2.5);
        objFuncMensTrab.setCargo("Cozinheira");
        System.out.println("\n\n\t\tFUNCIONÁRIO(A) MENSALISTA");
        System.out.println("Nome: " + objFuncMensTrab.getNome());
        System.out.println("Registro: " + objFuncMensTrab.getRegistro());
        System.out.println("Data de Admissão: " + objFuncMensTrab.getDtAdmissao());
        System.out.println("Cargo: " + objFuncMensTrab.getCargo());
        System.out.println("- Salário Bruto   => " + objFuncMensTrab.calcSalBruto());
        System.out.println("- Desconto        => " + objFuncMensTrab.calcDesconto());
        System.out.println("- Salário Líquido => " + objFuncMensTrab.calcSalLiquido());
        
        
        FuncionarioComissionado objFunComisTrab = new FuncionarioComissionado(1313, "Robson Silveira", 
                                                                                "11/05/2000", 25);
        
        do {
            System.out.println("---------------------------------------------------------------------");
            System.out.println("\tO funcionário comissionado realizou alguma venda?");
            System.out.println("1 - Sim");
            System.out.println("2 - Não");
            System.out.println("\t\tDigite a opção: ");
            opcao = entrada.nextInt();
            
            switch (opcao) {
                case 1:
                    
                    System.out.println("\nInforme o valor da venda: ");
                    valVenda = entrada.nextDouble();
                    objFunComisTrab.addVendas(valVenda);
                case 2:
                    System.out.println("---------------------------------------------------------------------");
                    break;
            }
        } while(opcao == 1);

            objFunComisTrab.setCargo("Ajudante");
            objFunComisTrab.setSalBase(450.00);
            System.out.println("\n\n\t\tFUNCIONÁRIO(A) COMISSIONADO");
            System.out.println("Nome: " + objFunComisTrab.getNome());
            System.out.println("Registro: " + objFunComisTrab.getRegistro());
            System.out.println("Data de Admissão: " + objFunComisTrab.getDtAdmissao());
            System.out.println("Cargo: " + objFunComisTrab.getCargo());
            System.out.println("- Salário Bruto       => " + objFunComisTrab.calcSalBruto());
            System.out.println("- Desconto            => " + objFunComisTrab.calcDesconto());
            System.out.println("- Salário Líquido     => " + objFunComisTrab.calcSalLiquido());
            System.out.println("- Gratificação        => " + objFunComisTrab.calcGratificacao());
            System.out.println("- Total das Vendas    => " + objFunComisTrab.getTotalVendas());
            System.out.println("- Taxa de Comissão    => " + objFunComisTrab.getTaxaComissao());
    }
}
