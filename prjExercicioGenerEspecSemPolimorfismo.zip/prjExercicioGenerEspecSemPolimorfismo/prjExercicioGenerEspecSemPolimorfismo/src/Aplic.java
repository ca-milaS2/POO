
import java.util.Scanner;
import fatec.poo.model.Cliente;
import fatec.poo.model.Instrutor;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        String nomeCliente, telefCliente, cpfCliente, nomeInstrutor, telefInstrutor, areaAtuacInstrutor;
        double pesoCliente, alturaCliente;
        int identInstrutor;
        
        System.out.println("\n---------------------------------------------------------------------------");
        System.out.println("Digite o nome do cliente: ");
        nomeCliente = entrada.nextLine();
        System.out.println("Digite o telefone do cliente: ");
        telefCliente = entrada.nextLine();
        System.out.println("Digite o cpf do cliente: ");
        cpfCliente = entrada.nextLine();
        System.out.println("\nAgora, digite o peso do cliente: ");
        pesoCliente = entrada.nextDouble();
        System.out.println("Digite a altura do cliente: ");
        alturaCliente = entrada.nextDouble();
        System.out.println("---------------------------------------------------------------------------");
        
        Cliente objCliente = new Cliente(cpfCliente, nomeCliente, telefCliente);
        objCliente.setPeso(pesoCliente);
        objCliente.setAltura(alturaCliente);
        
        System.out.println("\n\n---------------------------------------------------------------------------");
        System.out.println("Digite o nome do instrutor: ");
        entrada.nextLine();
        nomeInstrutor = entrada.nextLine();
        System.out.println("Digite o telefone do instrutor: ");
        telefInstrutor = entrada.nextLine();
        System.out.println("Digite a identificação do instrutor: ");
        identInstrutor = entrada.nextInt();
        System.out.println("\nAgora, digite a área de atuação do instrutor: ");
        entrada.nextLine();
        areaAtuacInstrutor = entrada.nextLine();
        System.out.println("---------------------------------------------------------------------------");
        
        Instrutor objInstrutor = new Instrutor(identInstrutor, nomeInstrutor, telefInstrutor);
        objInstrutor.setAreaAtuacao(areaAtuacInstrutor);
        
        System.out.println("\n\n\t\tCLIENTE");
        System.out.println("Nome: " + objCliente.getNome());
        System.out.println("Telefone: " + objCliente.getTelefone());
        System.out.println("CPF: " + objCliente.getCpf());
        System.out.println("Peso: " + objCliente.getPeso() + "kg");
        System.out.println("ALtura: " + objCliente.getAltura() + "m");
        
        System.out.println("\n\t\tINSTRUTOR");
        System.out.println("Nome: " + objInstrutor.getNome());
        System.out.println("Telefone: " + objInstrutor.getTelefone());
        System.out.println("Identidade: " + objInstrutor.getIdentificacao());
        System.out.println("Área de Atuação: " + objInstrutor.getAreaAtuacao());    
    }
}
