
import fatec.poo.model.Aluno;
import fatec.poo.model.Professor;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Aluno objAlu = new Aluno(1010, "Carlos Silveiro", "15/03/1978");
        objAlu.setMensalidade(1500);
        
        System.out.println("\t\tALUNO(A)");
        System.out.println("Registro Escolar: " + objAlu.getRegEscolar());
        System.out.println("Nome: " + objAlu.getNome());
        System.out.println("Data nascimento: " + objAlu.getDataNascimento());
        System.out.println("Mensalidade: " + objAlu.getMensalidade());
        
        Professor objProf = new Professor(2020, "Ana Carla", "03/09/1986");
        objProf.setSalario(5000);
        
        System.out.println("\n\n\t\tPROFESSOR(A)");
        System.out.println("Registro Funcional: " + objProf.getRegFuncional());
        System.out.println("Nome: " + objProf.getNome());
        System.out.println("Data Nascimento: " + objProf.getDataNascimento());
        System.out.println("Salário: " + objProf.getSalario());
    }
}
