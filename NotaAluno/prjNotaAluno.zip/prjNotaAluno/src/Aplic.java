
import java.util.Scanner;

/**
 *
 * @author Yuki
 */
public class Aplic {
    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);
        long raAluno;
        int opcao;
        double notaPrv1, notaPrv2, notaTrab1, notaTrab2;
        
        System.out.println("Digite o seu RA: ");
        raAluno = entrada.nextLong();
        System.out.println("Digite a nota da primeira prova: ");
        notaPrv1 = entrada.nextDouble();
        System.out.println("Digite a nota da segunda prova: ");
        notaPrv2 = entrada.nextDouble();
        System.out.println("Digite a nota do primeiro trabalho: ");
        notaTrab1 = entrada.nextDouble();
        System.out.println("Digite a nota do segundo trabalho: ");
        notaTrab2 = entrada.nextDouble();
        
        Aluno objAluno = new Aluno();
        objAluno.setRa(raAluno);
        objAluno.setNtPrv1(notaPrv1);
        objAluno.setNtPrv2(notaPrv2);
        objAluno.setNtTrab1(notaTrab1);
        objAluno.setNtTrab2(notaTrab2);
        
        do {
            System.out.println("\n\n1 - Exibir Nota das Provas/Trabalhos");
            System.out.println("2 - Exibir Média dos Trabalhos/Provas");
            System.out.println("3 - Exibir Média Final");
            System.out.println("4 - Sair");
            System.out.println("\n\t\tDigite a opção: ");
            opcao = entrada.nextInt();
            
            if(opcao >= 1 && opcao < 4) {
                System.out.println("\nRa do aluno(a): " + String.format("%013d", objAluno.getRa()));   
            }
            
            if(opcao == 1) {
                System.out.println("------------------------------------");
                System.out.println("- Nota da Primeira Prova:    " + objAluno.getNtPrv1());
                System.out.println("- Nota da Segunda Prova:     " + objAluno.getNtPrv2());
                System.out.println("- Nota do Primeiro Trabalho: " + objAluno.getNtTrab1());
                System.out.println("- Nota do Segundo Trabalho:  " + objAluno.getNtTrab2());
                System.out.println("------------------------------------");
            }
            else {
                if(opcao == 2) {
                    System.out.println("------------------------------------");
                    System.out.println("- Média dos Trabalhos: " + objAluno.calcMediaTrab());
                    System.out.println("- Média das Provas:    " + objAluno.calcMediaProva());
                    System.out.println("------------------------------------");
                }
                else {
                    if(opcao == 3) {
                        System.out.println("------------------------------------");
                        System.out.println("- Média Final: " + objAluno.calcMediaFinal());
                        System.out.println("------------------------------------");
                    }
                }
            }
            
        } while(opcao < 4);
    } 
}
